<?php

require_once 'const.php';
require_once 'helpers.php';

//load lib
require_once 'lib/shortcode-interface.php';

//load shortcodes
require_once 'shortcodes/booking-form/booking-form.php';

//load shortcodes inteface
require_once 'lib/shortcode-loader.php';
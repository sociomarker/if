<?php
/*
Plugin Name: Elated Instagram Feed
Description: Plugin that adds Instagram feed functionality to our theme
Author: Elated Themes
Version: 1.1
*/
define('ELATED_INSTAGRAM_FEED_VERSION', '1.1');

include_once 'load.php';
<div class="eltd-listing-list-preloader">
	<div class="eltd-st-loader">
		<?php
		if (eltd_listing_theme_installed()) {
			echo search_and_go_elated_loading_spinner_double_pulse();
		}
		?>
	</div>
</div>